# mynotes/db.py

import sqlite3
import bcrypt
from .commands import jsonData

DB_FILE = "notes.db"

def connect_to_database():
    return sqlite3.connect(host="localhost", user="root", password="", database="project1")

def create_tables():
    with connect_to_database() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password_hash TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_name TEXT UNIQUE,
                user_id INTEGER,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                unique_id TEXT UNIQUE,
                timestamp TEXT,
                note_text TEXT,
                group_name TEXT,
                user_id INTEGER,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        conn.commit()

def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

def create_user(username, password):
    create_tables()
    password_hash = hash_password(password)
    with connect_to_database() as conn:
        try:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)", (username, password_hash))
            conn.commit()
        except sqlite3.IntegrityError:
            print("Username already exists. Choose a different username.")

def authenticate_user(username, password):
    create_tables()
    with connect_to_database() as conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id, password_hash FROM users WHERE username=?", (username,))
            user_data = cursor.fetchone()

            if user_data and bcrypt.checkpw(password.encode('utf-8'), user_data[1]):
                return user_data[0]
            else:
                return None
        except Exception as e:
            print(f"Error during authentication: {e}")
            return None

def syncData():
    data = jsonData()
    with connect_to_database() as conn:
        cursor = conn.cursor()
        cursor.execute("select * from notes")
        notes = set(cursor.fetchall())
        notes.union(set(data["notes"]))
        conn.commit()
